def main():
    # Loop to print the first 20 even numbers
    for i in range(20):
        print(i * 2)

# Standard Python boilerplate to call main function
if __name__ == "__main__":
    main()

