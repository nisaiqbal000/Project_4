def main():
    # Countdown from 10 to 1
    for i in range(10, 0, -1):
        print(i)

    # Print Liftoff!
    print("Liftoff!")


# Call the main function when the script is executed
if __name__ == "__main__":
    main()


