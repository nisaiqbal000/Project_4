def main():
    # Get the number from the user
    num = float(input("Type a number to see its square: "))

    # Calculate and print the square
    print(f"{num} squared is {num ** 2}")

if __name__ == '__main__':
    main()


